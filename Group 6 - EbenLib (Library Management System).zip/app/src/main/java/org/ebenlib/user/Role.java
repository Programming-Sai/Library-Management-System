package org.ebenlib.user;

public enum Role {
    LIBRARIAN, MEMBER
}