package org.ebenlib.borrow;

public enum Status { PENDING, APPROVED, REJECTED, RETURNED }
